# The Santa Claus problem

### Para executar o arquivo utilize os seguintes comandos
	$gcc santa_claus.c -o santa_claus -pthread
	$./santa_claus

### Para entender a saida do programa 
	O programa imprime:
	- Rena/Elfo chegou: Avisa que Rena ou Elfo chegou e logo após imprime a quantidade atual deles e que 
	  o Papai Noel esta dormindo
	- Rena Pronta : Quando a Rena é arrumada pelo Papai Noel
	- Papai Noel acordou: Quando o Papai Noel é acordado pelas Renas ou Elfos.
	- Elfo recebeu ajuda : Quando o Elfo pede a ajuda do Papai Noel
	- Elfo ajudado : Quando o Papai noel ajuda os elfos
	- Preparar Rena : Quando o Papai noel prepara as renas


### Exemplo uso do Santa Claus problem
	O resolução do Santa Claus Problem pode ser utilizada em sistemas de tempo real onde se tem a necessidade de se esperar que um certo numeros de sinais tenham sido recebidos para que a aplicação execute um certo método ou prossiga, esse uso pode ser realizado em usinas nucleares e sistemas de aviões.
